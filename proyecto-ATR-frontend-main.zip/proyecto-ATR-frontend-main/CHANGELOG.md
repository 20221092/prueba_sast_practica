# Changelog

## [v1.8.0] - 2023-11-10
### Added
- Nueva funcionalidad X
- Soporte para Y

### Changed
- Mejora en el módulo Z