


export interface Cliente {
    _id?: string;
    nombre: string;
    email: string;
    telefono: string;
    numCasa: string;
    municipio:string;
    colonia: string;
    rol?: string;
    estatus?: string;
[key:string]:any
}
