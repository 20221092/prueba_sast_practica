export interface RedSocial {
  _id: any;
  plataforma: string;
  icon: string;
  enlace: string;
}
