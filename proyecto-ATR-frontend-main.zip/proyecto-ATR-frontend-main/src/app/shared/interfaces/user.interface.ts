export interface Iuser {
  email: string;
  _id: string;
  name: string;
  lastname: string;
  rol: string;
  iat: number;
  exp: number;
}
