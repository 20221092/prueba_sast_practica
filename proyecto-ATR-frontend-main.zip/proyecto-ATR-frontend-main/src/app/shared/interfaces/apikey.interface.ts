export interface ItokenResponse {
  _id: string;
  date: string;
  description: string;
  apiToken: string;
  // Otros campos según la respuesta real de tu API
}
