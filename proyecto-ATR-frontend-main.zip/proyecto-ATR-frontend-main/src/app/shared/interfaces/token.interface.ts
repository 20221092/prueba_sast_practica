// export interface ITokenResponse{
//   message:string,
//   code:number,
//   error:boolean,
//   data:Object,
// }
// export interface IToken{
//   name:string,
//   lastname:string,
// }
export interface IToken{
  token:string,
}
