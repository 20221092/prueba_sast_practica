export enum ERol
{
  ADMIN="ADMIN",
  CLIENTE = "CLIENTE",
  TITULAR = "TITULAR",
}
