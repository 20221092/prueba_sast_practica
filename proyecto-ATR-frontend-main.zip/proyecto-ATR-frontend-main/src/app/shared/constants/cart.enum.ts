export enum EIgv {
  IGV = 0.18
}
