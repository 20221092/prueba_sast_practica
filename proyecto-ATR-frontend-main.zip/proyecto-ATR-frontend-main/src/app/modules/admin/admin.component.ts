import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  // standalone: false,
  // imports: [RouteArOutlet],
  // 
  templateUrl: './admin.component.html',
  // styleUrl: './admin.component.scss'
})
export class AdminComponent {
  title = 'frontend';

  
}
