import { Component } from '@angular/core';

@Component({
  selector: 'app-constrol-accesorios-vestido',
  templateUrl: './constrol-accesorios-vestido.view.html',
  styleUrl: './constrol-accesorios-vestido.view.scss'
})
export class ConstrolAccesoriosVestidoView {

}
