import { Component } from '@angular/core';
@Component({
  selector: 'app-control-clientes',
  templateUrl: './control-clientes.view.html',
  styleUrl: './control-clientes.view.scss'
})
export class ControlClientesView {
 

}
