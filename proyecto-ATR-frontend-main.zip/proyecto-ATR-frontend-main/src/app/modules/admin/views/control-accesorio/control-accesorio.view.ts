import { Component } from '@angular/core';

@Component({
  selector: 'app-control-accesorio',
  templateUrl: './control-accesorio.view.html',
  // styleUrl: './control-accesorio.view.scss'
})
export class ControlAccesorioView {

}
