import { Component } from '@angular/core';

@Component({
  selector: 'app-reportes',
  templateUrl: './reportes.view.html',
  styleUrl: './reportes.view.scss'
})
export class ReportesView {

}
