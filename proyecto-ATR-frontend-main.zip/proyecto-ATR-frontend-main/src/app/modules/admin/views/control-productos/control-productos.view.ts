import { Component } from '@angular/core';
// 
@Component({
  selector: 'app-control-productos',
  templateUrl: './control-productos.view.html',
  // styleUrl: './control-productos.view.scss'
})
export class ControlProductosView {
  
}
