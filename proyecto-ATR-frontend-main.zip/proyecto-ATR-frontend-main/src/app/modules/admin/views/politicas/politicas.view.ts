import { Component } from '@angular/core';

@Component({
  selector: 'app-politicas',
  templateUrl: './politicas.view.html',
  styleUrl: './politicas.view.scss'
})
export class PoliticasView {

}
