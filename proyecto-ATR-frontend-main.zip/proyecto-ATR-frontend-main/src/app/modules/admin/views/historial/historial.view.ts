import { Component } from '@angular/core';
// import { CollapsedStateService } from '../../../../shared/services/collapsed-state.service';

@Component({
  selector: 'app-historial',
  templateUrl: './historial.view.html',
  styleUrl: './historial.view.scss'
})
export class HistorialView {
 
}
