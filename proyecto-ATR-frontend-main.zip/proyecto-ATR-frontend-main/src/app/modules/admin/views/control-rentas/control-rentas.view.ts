import { Component } from '@angular/core';
@Component({
  selector: 'app-control-rentas',
  templateUrl: './control-rentas.view.html',
  // styleUrl: './control-rentas.view.scss'
})
export class ControlRentasView {
 

}
