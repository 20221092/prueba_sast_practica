import { Component } from '@angular/core';

@Component({
  selector: 'app-perfilusuario',
  standalone: true,
  imports: [],
  templateUrl: './perfilusuario.component.html',
  styleUrl: './perfilusuario.component.scss'
})
export class PerfilusuarioComponent {

}
