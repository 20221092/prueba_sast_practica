import { Component } from '@angular/core';

@Component({
  selector: 'app-listado-comentario',
  templateUrl: './listado-comentario.component.html',
  styleUrl: './listado-comentario.component.scss'
})
export class ListadoComentarioComponent {

}
