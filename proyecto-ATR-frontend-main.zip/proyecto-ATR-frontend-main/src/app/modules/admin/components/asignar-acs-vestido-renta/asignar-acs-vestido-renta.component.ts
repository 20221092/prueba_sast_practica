import { Component } from '@angular/core';

@Component({
  selector: 'app-asignar-acs-vestido-renta',
  templateUrl: './asignar-acs-vestido-renta.component.html',
  styleUrl: './asignar-acs-vestido-renta.component.scss'
})
export class AsignarAcsVestidoRentaComponent {

}
