import { Component } from '@angular/core';
import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-documentos-legales',
  standalone: true,
  imports: [RouterModule],
  templateUrl: './documentos-legales.component.html',
  styleUrls: ['./documentos-legales.component.scss'],
})
export class DocumentosLegalesComponent {
 
}
