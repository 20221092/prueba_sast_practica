import { Component } from '@angular/core';

@Component({
  selector: 'app-perfil-empresa',
  standalone: true,
  imports: [],
  templateUrl: './perfil-empresa.component.html',
  styleUrl: './perfil-empresa.component.scss'
})
export class PerfilEmpresaComponent {

}
