import { Component } from '@angular/core';

@Component({
  selector: 'app-figure',
  templateUrl: './figure.component.html',
  // styleUrl: './figure.component.scss'
})
export class FigureComponent {

}
