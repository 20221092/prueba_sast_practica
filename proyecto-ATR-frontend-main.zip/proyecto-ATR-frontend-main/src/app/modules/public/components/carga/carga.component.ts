import { Component } from '@angular/core';

@Component({
  selector: 'app-carga',
  templateUrl: './carga.component.html',
  styleUrl: './carga.component.scss'
})
export class CargaComponent {

}
