import { Component } from '@angular/core';

@Component({
  selector: 'app-header-404',
  templateUrl: './header-404.component.html',
  styles: ``
  ,
  standalone:true
})
export class Header404Component {

}
