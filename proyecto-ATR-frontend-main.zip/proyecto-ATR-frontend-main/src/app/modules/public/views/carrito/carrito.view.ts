import { Component } from '@angular/core';

@Component({
  selector: 'app-carrito',
  templateUrl: './carrito.view.html',
  styleUrl: './carrito.view.scss'
})
export class CarritoView {

}
