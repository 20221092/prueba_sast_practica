import { Component } from '@angular/core';

@Component({
  selector: 'app-look-accesorio',
  templateUrl: './look-accesorio.component.html',
  styles: ``
})
export class LookAccesorioComponent {

}
