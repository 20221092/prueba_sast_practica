import { Component } from '@angular/core';

@Component({
  selector: 'app-informacion-user',
  templateUrl: './informacion-user.component.html',
  styleUrl: './informacion-user.component.scss'
})
export class InformacionUserComponent {

}
