import { Component } from '@angular/core';

@Component({
  selector: 'app-config',
  standalone: true,
  imports: [],
  templateUrl: './config.view.html',
  styleUrl: './config.view.scss'
})
export class ConfigView {

}
