import { Component } from '@angular/core';

@Component({
  selector: 'app-incluye-accesorio',
  templateUrl: './incluye-accesorio.view.html',
  styleUrl: './incluye-accesorio.view.scss'
})
export class IncluyeAccesorioView {

}
