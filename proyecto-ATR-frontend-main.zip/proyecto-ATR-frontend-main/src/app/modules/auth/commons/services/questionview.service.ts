// import { Injectable } from '@angular/core';
// import { BehaviorSubject } from 'rxjs';

// @Injectable({
//   providedIn: 'root'
// })
// export class QuestionviewService {

//   private visibleSubject = new BehaviorSubject<boolean>(false);
//   public visible$ = this.visibleSubject.asObservable();

//   constructor() { }

//   showQuestion() {
//     this.visibleSubject.next(true);
//   }

//   hideQuestion() {
//     this.visibleSubject.next(false);
//   }
// }
