export interface ISingInRequest
{
  email:string,
  password:string,
  telefono:string,
  captchaToken:any
}
