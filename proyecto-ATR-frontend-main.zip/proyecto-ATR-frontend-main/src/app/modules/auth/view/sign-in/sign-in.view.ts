import { Component } from '@angular/core';

@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.view.html',
  styles: ``
})
export class SignInView {

}
