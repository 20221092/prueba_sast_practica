declare module '@toast-ui/calendar' {
  import Calendar from '@toast-ui/calendar/types/index';
  export default Calendar;
}
